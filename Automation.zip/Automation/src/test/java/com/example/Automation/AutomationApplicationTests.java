package com.example.Automation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutomationApplicationTests {

	@Test
	void contextLoads() {
	}

}
